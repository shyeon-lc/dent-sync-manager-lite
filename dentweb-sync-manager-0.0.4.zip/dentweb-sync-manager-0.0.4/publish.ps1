# DentWeb Sync Manager Build Script (publish.ps1)

$ProjectRoot = "C:\works\wpf\dentweb-sync-manager"
$ProjectDir = "$ProjectRoot\DentWebSyncManager"
$ReleaseDir = "$ProjectDir\bin\Release"
$PublishDir = "$ProjectDir\bin\Release\net10.0-windows\win-x64\publish"
$InstallerOutputDir = "$ProjectRoot\Output"

Write-Host "--------------------------------------------------" -ForegroundColor Cyan
Write-Host "🚀 배포 빌드 및 클린업을 시작합니다" -ForegroundColor Cyan
Write-Host "--------------------------------------------------" -ForegroundColor Cyan

# 1. 이전 빌드 결과물 전체 삭제 (Release 폴더)
if (Test-Path $ReleaseDir) {
    Write-Host "🧹 기존 bin\Release 폴더를 삭제 중..." -ForegroundColor Gray
    Remove-Item -Recurse -Force $ReleaseDir -ErrorAction SilentlyContinue
}

# 2. 기존 설치 파일 폴더 삭제 (Output 폴더)
if (Test-Path $InstallerOutputDir) {
    Write-Host "🧹 기존 Installer Output 폴더를 삭제 중..." -ForegroundColor Gray
    Remove-Item -Recurse -Force $InstallerOutputDir -ErrorAction SilentlyContinue
}

# 3. dotnet publish 명령어 실행
dotnet publish $ProjectDir `
    -c Release `
    -r win-x64 `
    --self-contained true `
    -p:PublishSingleFile=true `
    -p:PublishReadyToRun=true `
    -p:IncludeNativeLibrariesForSelfExtract=true

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✅ 빌드가 성공적으로 완료되었습니다!" -ForegroundColor Green
    Write-Host "📂 빌드 출력: $PublishDir" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "이제 Inno Setup에서 installer_script.iss를 컴파일하세요." -ForegroundColor White
} else {
    Write-Host ""
    Write-Host "❌ 빌드 중 오류가 발생했습니다." -ForegroundColor Red
    exit $LASTEXITCODE
}
