using DentWebSyncManager.Services;
using Microsoft.Extensions.Hosting;

namespace DentWebSyncManager.Workers;

public class Task4Worker(
    ITaskService taskService,
    ILogService logService,
    IAppStateService appState) : BackgroundService
{
    private bool _hasRunToday = false;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            if (appState.IsTask4Enabled)
            {
                var now = DateTime.Now;
                var today10Am = now.Date.AddHours(10);

                // Catch-up or Scheduled run
                if (now >= today10Am && !_hasRunToday)
                {
                    try
                    {
                        await taskService.ExecuteTask4Async();
                        _hasRunToday = true;
                    }
                    catch (Exception ex)
                    {
                        logService.Log($"[Task 4 Error] {ex.Message}");
                    }
                }
                else if (now < today10Am)
                {
                    _hasRunToday = false;
                }
            }
            else
            {
                _hasRunToday = false; // Reset if disabled
            }

            // Check every minute
            try
            {
                await Task.Delay(TimeSpan.FromMinutes(1), stoppingToken);
            }
            catch (OperationCanceledException) { break; }
        }
    }
}
