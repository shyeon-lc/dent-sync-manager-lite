using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using DentWebSyncManager.Configuration;
using DentWebSyncManager.Records;
using DentWebSyncManager.Services;
using Microsoft.Extensions.Hosting;

namespace DentWebSyncManager.Workers;

public class HealthCheckWorker(
    ITaskService taskService,
    ILogService logService,
    IHttpClientFactory httpClientFactory,
    IAppStateService appState) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // One-time startup registration
        taskService.RegisterInStartup();

        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(30));
        
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await PerformHealthCheckAsync(stoppingToken);
            }
            catch (Exception)
            {
                // Silent fail for health check to avoid log spamming if server is down
            }

            try
            {
                await timer.WaitForNextTickAsync(stoppingToken);
            }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task PerformHealthCheckAsync(CancellationToken ct)
    {
        string apiUrl = "https://gateway.medilawyer.co.kr/crawling/apis/unrestricted/dentweb/sync/health";
        long currentEpoch = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        
        var requestData = new HealthCheckRequest(appState.StoreId, AppConstants.AppVersion, currentEpoch);

        using var client = httpClientFactory.CreateClient();
        var response = await client.PostAsJsonAsync(apiUrl, requestData, ct);

        if (response.IsSuccessStatusCode)
        {
            var responseData = await response.Content.ReadFromJsonAsync<HealthCheckResponse>(cancellationToken: ct);
            
            if (responseData is { status: 200 })
            {
                var result = responseData.result;

                if (result.need_update)
                {
                    logService.Log($"[시스템 알림] 새 버전({result.target_version}) 업데이트가 필요합니다!");
                }

                if (result.target_names != null && result.target_names.Any())
                {
                    logService.Log($"[Health Check] 서버로부터 {result.target_names.Count}명의 명단을 받아 자동 동기화를 시작합니다.");

                    await File.WriteAllLinesAsync(AppConstants.TargetNamesFile, result.target_names, Encoding.UTF8, ct);
                    
                    await taskService.RunTask2Async(ct);

                    await File.WriteAllTextAsync(AppConstants.TargetNamesFile, string.Empty, ct);
                    logService.Log("[Health Check] 특정 명단 자동 동기화 완료 후 로컬 명단을 비웠습니다.");
                }
            }
        }
    }
}
