using DentWebSyncManager.Services;
using Microsoft.Extensions.Hosting;

namespace DentWebSyncManager.Workers;

public class Task3Worker(
    ITaskService taskService,
    ILogService logService,
    IAppStateService appState) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(5));
        
        while (!stoppingToken.IsCancellationRequested)
        {
            if (appState.IsTask3Enabled)
            {
                try
                {
                    await taskService.ExecuteTask3Async();
                    logService.Log("Task3 주기 완료. 5분 대기...");
                }
                catch (Exception ex)
                {
                    logService.Log($"[Task 3 Error] {ex.Message}");
                }
            }

            try
            {
                await timer.WaitForNextTickAsync(stoppingToken);
            }
            catch (OperationCanceledException) { break; }
        }
    }
}
