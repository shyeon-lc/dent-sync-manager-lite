namespace DentWebSyncManager.Models;

public class Task3SyncState
{
    public string LastSyncDate { get; set; } = "";
    public List<int> SentPatientIds { get; set; } = new List<int>();
}