namespace DentWebSyncManager.Configuration;

public class AppOptions
{
    public string DbIp { get; set; } = string.Empty;
    public string StoreId { get; set; } = string.Empty;
    
    // Task States
    public bool IsTask1Running { get; set; }
    public bool IsTask2Running { get; set; }
    public bool IsTask3Enabled { get; set; }
    public bool IsTask4Enabled { get; set; }
    public bool IsTask5Running { get; set; }
    public DateTime? Task5Date { get; set; }
    public bool IsTask6Running { get; set; }
}
