namespace DentWebSyncManager.Configuration;

public static class AppConstants
{
    public const string AppVersion = "0.0.4";
    
    // File Paths
    public const string CursorFile = "last_patient_id.txt";
    public const string TargetNamesFile = "target_names.txt";
    // Task 6: 메디컨텐츠용 특정 명단 전체 진료기록 동기화 (Task 2와 별도 파일, 수동 명단)
    public const string TargetNamesFullFile = "target_names_medicontents.txt";
    public const string Task3StateFile = "task3_state.json";
    public const string AppSettingsFile = "config.json";
}
