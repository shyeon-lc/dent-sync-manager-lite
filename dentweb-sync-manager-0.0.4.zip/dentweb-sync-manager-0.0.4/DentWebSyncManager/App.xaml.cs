﻿using System.IO;
using System.Windows;
using DentWebSyncManager.Configuration;
using DentWebSyncManager.Services;
using DentWebSyncManager.ViewModels;
using DentWebSyncManager.Workers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Application = System.Windows.Application;

namespace DentWebSyncManager;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
    private readonly IHost _host;

    public App()
    {
        // Fix working directory for auto-startup (Registry Run key)
        Directory.SetCurrentDirectory(AppContext.BaseDirectory);

        _host = Host.CreateDefaultBuilder()
            .ConfigureAppConfiguration((context, config) =>
            {
                config.SetBasePath(AppContext.BaseDirectory);
                config.AddJsonFile(AppConstants.AppSettingsFile, optional: true, reloadOnChange: true);
            })
            .ConfigureServices((context, services) =>
            {
                // Configuration
                services.Configure<AppOptions>(context.Configuration);

                // Services
                services.AddHttpClient();
                services.AddSingleton<ILogService, LogService>();
                services.AddSingleton<IAppStateService, AppStateService>();
                services.AddSingleton<ISyncService, SyncService>();
                services.AddSingleton<ITaskService, TaskService>();
                
                // Workers
                services.AddHostedService<HealthCheckWorker>();
                services.AddHostedService<Task3Worker>();
                services.AddHostedService<Task4Worker>();

                // ViewModels
                services.AddSingleton<MainViewModel>();

                // Windows
                services.AddSingleton<MainWindow>(s => new MainWindow()
                {
                    DataContext = s.GetRequiredService<MainViewModel>()
                });
            })
            .Build();
    }

    protected override async void OnStartup(StartupEventArgs e)
    {
        await _host.StartAsync();

        var mainViewModel = _host.Services.GetRequiredService<MainViewModel>();
        var mainWindow = _host.Services.GetRequiredService<MainWindow>();
        mainWindow.Show();

        // Resume active tasks
        await mainViewModel.InitializeAsync();

        base.OnStartup(e);
    }

    protected override async void OnExit(ExitEventArgs e)
    {
        _host.Services.GetRequiredService<MainViewModel>().OnExit();
        using (_host)
        {
            await _host.StopAsync();
        }

        base.OnExit(e);
    }
}