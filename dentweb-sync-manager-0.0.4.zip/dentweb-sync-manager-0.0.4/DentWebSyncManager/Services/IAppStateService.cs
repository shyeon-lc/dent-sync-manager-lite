using System;
using System.IO;
using System.Text.Json;
using CommunityToolkit.Mvvm.ComponentModel;
using Microsoft.Extensions.Options;
using DentWebSyncManager.Configuration;

namespace DentWebSyncManager.Services;

public interface IAppStateService
{
    string DbIp { get; set; }
    string StoreId { get; set; }
    bool IsTask1Running { get; set; }
    bool IsTask2Running { get; set; }
    bool IsTask3Enabled { get; set; }
    bool IsTask4Enabled { get; set; }
    bool IsTask5Running { get; set; }
    DateTime? Task5Date { get; set; }
    bool IsTask6Running { get; set; }
    void SaveSettings();
}

public class AppStateService : ObservableObject, IAppStateService
{
    private string _dbIp = string.Empty;
    public string DbIp
    {
        get => _dbIp;
        set => SetProperty(ref _dbIp, value);
    }

    private string _storeId = string.Empty;
    public string StoreId
    {
        get => _storeId;
        set => SetProperty(ref _storeId, value);
    }

    private bool _isTask1Running;
    public bool IsTask1Running
    {
        get => _isTask1Running;
        set => SetProperty(ref _isTask1Running, value);
    }

    private bool _isTask2Running;
    public bool IsTask2Running
    {
        get => _isTask2Running;
        set => SetProperty(ref _isTask2Running, value);
    }

    private bool _isTask3Enabled;
    public bool IsTask3Enabled
    {
        get => _isTask3Enabled;
        set => SetProperty(ref _isTask3Enabled, value);
    }

    private bool _isTask4Enabled;
    public bool IsTask4Enabled
    {
        get => _isTask4Enabled;
        set => SetProperty(ref _isTask4Enabled, value);
    }

    private bool _isTask5Running;
    public bool IsTask5Running
    {
        get => _isTask5Running;
        set => SetProperty(ref _isTask5Running, value);
    }

    private DateTime? _task5Date;
    public DateTime? Task5Date
    {
        get => _task5Date;
        set => SetProperty(ref _task5Date, value);
    }

    private bool _isTask6Running;
    public bool IsTask6Running
    {
        get => _isTask6Running;
        set => SetProperty(ref _isTask6Running, value);
    }

    public AppStateService(IOptions<AppOptions> options)
    {
        // Initialize from appsettings/config.json loaded at startup
        DbIp = options.Value.DbIp;
        StoreId = options.Value.StoreId;
        IsTask1Running = options.Value.IsTask1Running;
        IsTask2Running = options.Value.IsTask2Running;
        IsTask3Enabled = options.Value.IsTask3Enabled;
        IsTask4Enabled = options.Value.IsTask4Enabled;
        IsTask5Running = options.Value.IsTask5Running;
        Task5Date = options.Value.Task5Date ?? DateTime.Now;
        IsTask6Running = options.Value.IsTask6Running;
    }

    public void SaveSettings()
    {
        try
        {
            var config = new AppOptions
            {
                DbIp = DbIp,
                StoreId = StoreId,
                IsTask1Running = IsTask1Running,
                IsTask2Running = IsTask2Running,
                IsTask3Enabled = IsTask3Enabled,
                IsTask4Enabled = IsTask4Enabled,
                IsTask5Running = IsTask5Running,
                Task5Date = Task5Date,
                IsTask6Running = IsTask6Running
            };
            File.WriteAllText(AppConstants.AppSettingsFile, JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception)
        {
            // Logging could be injected here if needed, but keeping it simple for persistence
        }
    }
}
