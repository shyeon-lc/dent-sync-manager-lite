using System.Data;
using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Dapper;
using DentWebSyncManager.Configuration;
using DentWebSyncManager.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Win32;

namespace DentWebSyncManager.Services;

public interface ITaskService
{
    Task<bool> TestDbConnectionAsync();
    void RegisterInStartup();
    Task RunTask1Async(CancellationToken ct);
    Task RunTask2Async(CancellationToken ct);
    Task ExecuteTask3Async();
    Task ExecuteTask4Async();
    Task RunTask5Async(string targetDateStr, CancellationToken ct);
    Task RunTask6Async(CancellationToken ct);
}

public class TaskService(
    ISyncService syncService,
    ILogService logService,
    IHttpClientFactory httpClientFactory,
    IAppStateService appState) : ITaskService
{
    private string GetConnStr() => $"Server={appState.DbIp.Trim()},1436;Database=DentWeb;User ID=dwpublic;Password=dwpublic2!;TrustServerCertificate=True;";
    private string GetReceiveUrl() => $"https://gateway.medilawyer.co.kr/crawling/apis/unrestricted/review-booster/receive-patient-info/{appState.StoreId.Trim()}";

    public async Task<bool> TestDbConnectionAsync()
    {
        try
        {
            var testBuilder = new SqlConnectionStringBuilder(GetConnStr())
            {
                ConnectTimeout = 5 
            };

            using var conn = new SqlConnection(testBuilder.ConnectionString);
            await conn.OpenAsync();
            return true;
        }
        catch (Exception ex)
        {
            logService.Log($"❌ [실패] 연결 오류: {ex.Message}");
            return false;
        }
    }

    public void RegisterInStartup()
    {
        try
        {
            string? appPath = Environment.ProcessPath;
            if (appPath != null)
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
                key?.SetValue("DentWebSyncManager", appPath);
            }
        }
        catch { }
    }

    public async Task RunTask1Async(CancellationToken ct)
    {
        try {
            using var conn = new SqlConnection(GetConnStr());
            var patients = (await conn.QueryAsync<dynamic>("SELECT n환자ID, b성별, sz차트번호, n담당의사, sz이름, sz생년월일 FROM DentWeb.dbo.PUB_V환자정보 WHERE n환자ID < @ID ORDER BY n환자ID DESC", new { ID = GetLastId() })).ToList();
            foreach (var p in patients) {
                if (ct.IsCancellationRequested) break;
                try {
                    await syncService.ProcessSinglePatientAsync(Convert.ToInt32(p.n환자ID), p);
                    SaveLastId(Convert.ToInt32(p.n환자ID));
                    logService.Log($"Task1 전송: {p.sz이름}");
                }
                catch {}
            }
        }
        catch (Exception ex) {
            logService.Log($"[Task1 작업 중단] DB 연결 또는 쿼리 오류: {ex.Message}");
        }
    }

    public async Task RunTask2Async(CancellationToken ct)
    {
        try {
            logService.Log("[Task 2] 특정 명단 동기화 시작...");
            if (!File.Exists(AppConstants.TargetNamesFile)) { logService.Log($"{AppConstants.TargetNamesFile} 파일이 없습니다."); return; }
            
            var targetNames = (await File.ReadAllLinesAsync(AppConstants.TargetNamesFile, Encoding.UTF8)).Where(n => !string.IsNullOrWhiteSpace(n)).Select(n => n.Trim()).ToList();
            using var conn = new SqlConnection(GetConnStr());
            foreach (var name in targetNames)
            {
                if (ct.IsCancellationRequested) break;
                var patients = (await conn.QueryAsync<dynamic>("SELECT n환자ID, b성별, sz차트번호, n담당의사, sz이름, sz생년월일 FROM DentWeb.dbo.PUB_V환자정보 WHERE sz이름 = @TargetName", new { TargetName = name })).ToList();
                foreach (var p in patients)
                    try
                    {
                        await syncService.ProcessSinglePatientAsync(Convert.ToInt32(p.n환자ID), p);
                        logService.Log($"Task2 성공: {name}");
                    }
                    catch (Exception ex)
                    {
                        logService.Log($"Task2 실패: {name} - {ex.Message}");
                    }
            }
        }
        catch (Exception ex) {
            logService.Log($"[Task2 작업 중단] DB 연결 또는 쿼리 오류: {ex.Message}");
        }
    }

    // [Task 6] 메디컨텐츠용: 특정 명단(별도 파일)의 환자당 '전체 진료기록'을 전송한다.
    // RunTask2Async를 미러링하되, 수동 명단이므로 실행 후 파일을 비우지 않는다(HealthCheck 흐름과 다름).
    public async Task RunTask6Async(CancellationToken ct)
    {
        try {
            logService.Log("▶ [Task 6] 특정 명단 전체 진료기록 동기화 시작... (메디컨텐츠용)");
            if (!File.Exists(AppConstants.TargetNamesFullFile)) { logService.Log($"{AppConstants.TargetNamesFullFile} 파일이 없습니다."); return; }

            var targetNames = (await File.ReadAllLinesAsync(AppConstants.TargetNamesFullFile, Encoding.UTF8)).Where(n => !string.IsNullOrWhiteSpace(n)).Select(n => n.Trim()).ToList();
            using var conn = new SqlConnection(GetConnStr());
            foreach (var name in targetNames)
            {
                if (ct.IsCancellationRequested) break;
                var patients = (await conn.QueryAsync<dynamic>("SELECT n환자ID, b성별, sz차트번호, n담당의사, sz이름, sz생년월일 FROM DentWeb.dbo.PUB_V환자정보 WHERE sz이름 = @TargetName", new { TargetName = name })).ToList();
                foreach (var p in patients)
                    try
                    {
                        await syncService.ProcessSinglePatientFullHistoryAsync(Convert.ToInt32(p.n환자ID), p, ct);
                        logService.Log($"Task6 성공: {name}");
                    }
                    catch (OperationCanceledException) when (ct.IsCancellationRequested)
                    {
                        logService.Log("🛑 Task6 작업이 사용자 요청으로 중단되었습니다.");
                        return;
                    }
                    catch (Exception ex)
                    {
                        logService.Log($"Task6 실패: {name} - {ex.Message}");
                    }
            }
            // 수동 명단이므로 target_names_medicontents.txt 파일은 비우지 않는다.
            logService.Log("✅ Task6 특정 명단 전체 진료기록 동기화 완료");
        }
        catch (Exception ex) {
            logService.Log($"[Task6 작업 중단] DB 연결 또는 쿼리 오류: {ex.Message}");
        }
    }

    public async Task ExecuteTask3Async()
    {
        string today = DateTime.Now.ToString("yyyyMMdd");
        var syncState = LoadTask3State();
        
        if (syncState.LastSyncDate != today)
        {
            syncState.LastSyncDate = today;
            syncState.SentPatientIds.Clear();
        }

        using var conn = new SqlConnection(GetConnStr());
        var raw = await conn.QueryAsync<dynamic>("DentWeb.dbo.PUB_P접수목록", new { SZ날짜 = today }, commandType: CommandType.StoredProcedure);
        var target = raw.Where(p => p.n상태 == 4 && !syncState.SentPatientIds.Contains(Convert.ToInt32(p.n환자ID))).ToList();
        
        if (!target.Any()) return;
        
        logService.Log($"[Task 3] 신규 당일 접수현황 {target.Count}건 일괄 전송 시작...");
        try
        {
            var allPayments = (await conn.QueryAsync<dynamic>("SELECT n환자ID, sz수납시각, n카드수납액, sz진료일 FROM DentWeb.dbo.PUB_V진료비내역 WHERE sz진료일 = @SearchDate AND sz수납시각 IS NOT NULL", new { SearchDate = today })).ToList();
            var payload = new List<object>();

            foreach (var p in target)
            {
                int pId = Convert.ToInt32(p.n환자ID);
                var matchingPayments = allPayments.Where(pay => Convert.ToInt32(pay.n환자ID) == pId).Select(pay => new { card_payment = pay.n카드수납액, payment_date = pay.sz수납시각?.ToString() }).ToList();
                
                payload.Add(new {
                    status = p.n상태, chart_number = p.sz차트번호?.ToString(), name = p.sz이름?.ToString(), is_new_patient = p.b신환여부,
                    checkin_time = p.sz접수시각?.ToString(), reservation_time = p.sz예약시각?.ToString(), doctor_id = p.n담당의사,
                    phone_number = p.sz전화번호?.ToString(), mobile_number = p.sz휴대폰번호?.ToString(), notes = p.접수내용?.ToString(),
                    patient_id = pId, staff = p.담당직원?.ToString(), chair = p.체어?.ToString(), gender = p.b성별, birth_date = p.sz생년월일?.ToString(),
                    payment_details = matchingPayments
                });
            }
            
            using var client = httpClientFactory.CreateClient();
            var response = await client.PostAsJsonAsync(GetReceiveUrl(), payload);
            
            if (response.IsSuccessStatusCode) 
            {
                logService.Log($"Task3 성공: 총 {payload.Count}건 일괄 전송 완료");
                foreach(var p in target)
                {
                    syncState.SentPatientIds.Add(Convert.ToInt32(p.n환자ID));
                }
                SaveTask3State(syncState);
            }
            else 
            {
                logService.Log($"Task3 전송 실패: {await response.Content.ReadAsStringAsync()}");
            }
        }
        catch (Exception ex) { logService.Log($"Task3 오류: {ex.Message}"); }
    }

    public async Task ExecuteTask4Async() {
        try {
            logService.Log("[Task 4] 전일 수납내역 동기화 시작...");
            DateTime targetDate = DateTime.Now.DayOfWeek == DayOfWeek.Monday ? DateTime.Now.AddDays(-2) : DateTime.Now.AddDays(-1);
            string targetDateStr = targetDate.ToString("yyyyMMdd");
            
            using var conn = new SqlConnection(GetConnStr());
            var rawResults = await conn.QueryAsync<dynamic>("DentWeb.dbo.PUB_P접수목록", new { sz날짜 = targetDateStr }, commandType: CommandType.StoredProcedure);
            var targetPatients = rawResults.Where(p => p.n상태 == 4).ToList();
            
            if (!targetPatients.Any()) logService.Log($"{targetDateStr} 수납 환자 없음.");
            else foreach (var p in targetPatients)
            {
                try
                {
                    await syncService.ProcessSinglePatientAsync(Convert.ToInt32(p.n환자ID), p);
                    logService.Log($"Task4 성공: {p.sz이름}");
                }
                catch (Exception ex)
                {
                    logService.Log($"Task4 실패: {p.sz이름} - {ex.Message}");
                }
            }
            logService.Log("Task4 정기 실행 완료");
        }
        catch (Exception ex) {
            logService.Log($"[Task4 작업 중단] DB 연결 또는 쿼리 오류: {ex.Message}");
        }
    }

    public async Task RunTask5Async(string targetDateStr, CancellationToken ct)
    {
        try {
            using var conn = new SqlConnection(GetConnStr());
            var rawResults = await conn.QueryAsync<dynamic>("DentWeb.dbo.PUB_P접수목록", new { sz날짜 = targetDateStr }, commandType: CommandType.StoredProcedure);
            var targetPatients = rawResults.Where(p => p.n상태 == 4).ToList();

            if (!targetPatients.Any()) {
                logService.Log($"{targetDateStr} 수납 환자 없음.");
                return;
            }

            logService.Log($"[Task 5] {targetDateStr} 수납 환자 {targetPatients.Count}명 동기화 시작...");

            foreach (var p in targetPatients) {
                if (ct.IsCancellationRequested) break;
                try {
                    await syncService.ProcessSinglePatientAsync(Convert.ToInt32(p.n환자ID), p);
                    logService.Log($"Task5 성공: {p.sz이름}");
                } catch (Exception ex) {
                    logService.Log($"Task5 실패: {p.sz이름} - {ex.Message}");
                }
            }
            logService.Log($"Task5 {targetDateStr} 동기화 완료");
        } catch (Exception ex) {
            logService.Log($"[Task5 작업 중단] DB 연결 또는 쿼리 오류: {ex.Message}");
        }
    }

    private int GetLastId() => File.Exists(AppConstants.CursorFile) ? int.Parse(File.ReadAllText(AppConstants.CursorFile)) : int.MaxValue;
    private void SaveLastId(int id) => File.WriteAllText(AppConstants.CursorFile, id.ToString());

    private Task3SyncState LoadTask3State()
    {
        if (File.Exists(AppConstants.Task3StateFile))
        {
            try
            {
                string json = File.ReadAllText(AppConstants.Task3StateFile);
                return JsonSerializer.Deserialize<Task3SyncState>(json) ?? new Task3SyncState();
            }
            catch { }
        }
        return new Task3SyncState();
    }

    private void SaveTask3State(Task3SyncState state)
    {
        File.WriteAllText(AppConstants.Task3StateFile, JsonSerializer.Serialize(state));
    }
}