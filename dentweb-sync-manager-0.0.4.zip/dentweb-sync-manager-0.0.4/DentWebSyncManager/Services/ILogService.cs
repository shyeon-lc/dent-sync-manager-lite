namespace DentWebSyncManager.Services;

public interface ILogService
{
    event Action<string>? OnLogReceived;
    void Log(string message);
}

public class LogService : ILogService
{
    public event Action<string>? OnLogReceived;

    public void Log(string message)
    {
        OnLogReceived?.Invoke(message);
    }
}
