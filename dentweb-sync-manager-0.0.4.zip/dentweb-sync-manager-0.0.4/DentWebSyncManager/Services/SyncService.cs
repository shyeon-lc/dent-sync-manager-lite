using System.Data;
using System.Net.Http;
using System.Net.Http.Json;
using Dapper;
using DentWebSyncManager.Records;
using Microsoft.Data.SqlClient;

namespace DentWebSyncManager.Services;

public interface ISyncService
{
    Task ProcessSinglePatientAsync(int patientId, dynamic basicInfo);
    // Task 6: 환자 1명의 전체 진료기록(모든 진료일)을 진료일별 레코드로 1회 POST 전송 (메디컨텐츠용)
    Task ProcessSinglePatientFullHistoryAsync(int patientId, dynamic basicInfo, CancellationToken ct = default);
}

public class SyncService(IHttpClientFactory httpClientFactory, IAppStateService appState) : ISyncService
{
    private string GetConnStr() => $"Server={appState.DbIp.Trim()},1436;Database=DentWeb;User ID=dwpublic;Password=dwpublic2!;TrustServerCertificate=True;";
    private string GetInfoUrl() => $"https://gateway.medilawyer.co.kr/crawling/apis/unrestricted/review-booster/medicontents/patient-info/{appState.StoreId.Trim()}";

    public async Task ProcessSinglePatientAsync(int patientId, dynamic basicInfo)
    {
        using var conn = new SqlConnection(GetConnStr());
        await conn.OpenAsync();

        // Dapper의 dynamic 객체를 안전하게 다루기 위해 Dictionary로 캐스팅
        var infoDict = (IDictionary<string, object>)basicInfo;

        // 1. 의사 이름 조회
        string? doctorName = null;
        if (infoDict.ContainsKey("n담당의사") && infoDict["n담당의사"] != null)
        {
            doctorName = await conn.QueryFirstOrDefaultAsync<string>(
                "SELECT sz이름 FROM DentWeb.dbo.PUB_V직원정보 WHERE nID = @id", new { id = Convert.ToInt32(infoDict["n담당의사"]) });
        }

        // 2. 최신 진료 내역 조회
        var treatment = await conn.QueryFirstOrDefaultAsync(
            "SELECT TOP 1 sz진료일, sz치료내용 FROM DentWeb.dbo.PUB_V진료비내역 WHERE n환자ID = @id ORDER BY sz진료일 DESC", 
            new { id = patientId });

        // 3. 엑스레이 이미지 수집
        var images = await FetchXrayImagesAsync(conn, patientId);

        // [패치] 예약시간/접수시간 14자리 -> 12자리 자르기 (PS 스크립트 동일 로직)
        string? rawTime = null;
        if (infoDict.ContainsKey("sz접수시각") && infoDict["sz접수시각"] != null) rawTime = infoDict["sz접수시각"].ToString();
        else if (infoDict.ContainsKey("sz예약시각") && infoDict["sz예약시각"] != null) rawTime = infoDict["sz예약시각"].ToString();
        
        if (!string.IsNullOrEmpty(rawTime) && rawTime.Length >= 12)
        {
            rawTime = rawTime.Substring(0, 12);
        }

        // [패치] 접수내용/예약내용 매핑
        string? resNotes = null;
        if (infoDict.ContainsKey("접수내용") && infoDict["접수내용"] != null) resNotes = infoDict["접수내용"].ToString();
        else if (infoDict.ContainsKey("sz예약내용") && infoDict["sz예약내용"] != null) resNotes = infoDict["sz예약내용"].ToString();

        // 4. 최종 데이터 구조 조립
        var finalData = new PatientFullDetail(
            patientId,
            infoDict.ContainsKey("b성별") ? infoDict["b성별"] : null,
            infoDict.ContainsKey("sz생년월일") ? infoDict["sz생년월일"]?.ToString() : null,
            infoDict.ContainsKey("sz차트번호") ? infoDict["sz차트번호"]?.ToString() : null,
            treatment?.sz진료일,
            infoDict.ContainsKey("sz이름") ? infoDict["sz이름"]?.ToString() : null,
            resNotes,
            null,
            treatment?.sz치료내용,
            doctorName,
            reservation_time: rawTime, // 12자리로 정제된 시간
            images: images
        );

        // 5. API 전송
        await SendToApiAsync(finalData);
    }

    // [Task 6] 특정 명단 전용: 환자당 전체 진료기록(모든 진료일)을 진료일별 레코드로 만들어 1회 POST로 전송한다.
    // 기존 ProcessSinglePatientAsync(최신 1건)와 병렬로 존재하며, 서로의 동작에 영향을 주지 않는다.
    public async Task ProcessSinglePatientFullHistoryAsync(int patientId, dynamic basicInfo, CancellationToken ct = default)
    {
        using var conn = new SqlConnection(GetConnStr());
        await conn.OpenAsync(ct);

        // Dapper의 dynamic 객체를 안전하게 다루기 위해 Dictionary로 캐스팅
        var infoDict = (IDictionary<string, object>)basicInfo;

        // 1. 의사 이름 조회 (기존 로직과 동일)
        string? doctorName = await GetDoctorNameAsync(conn, infoDict);

        // 2. 전체 진료내역 조회 (진료일 내림차순, 진료일 NULL 제외)
        // sz진료일 > '19001231': 덴트웹이 날짜 미상 시 쓰는 센티널(1900-12-31) 및 그 이전 값 제외 (서버 실데이터에서 확인됨)
        var treatments = (await conn.QueryAsync(new CommandDefinition(
            "SELECT sz진료일, sz치료내용 FROM DentWeb.dbo.PUB_V진료비내역 WHERE n환자ID = @id AND sz진료일 IS NOT NULL AND sz진료일 > '19001231' ORDER BY sz진료일 DESC",
            new { id = patientId }, cancellationToken: ct))).ToList();

        // 3. 엑스레이 이미지 수집 (전체 한 번에 조회 후 진료일별로 배분)
        var images = await FetchXrayImagesAsync(conn, patientId);
        ct.ThrowIfCancellationRequested();

        // [패치] 예약시간/접수시간 14자리 -> 12자리 자르기 (기존 메서드 동일 로직)
        string? rawTime = null;
        if (infoDict.ContainsKey("sz접수시각") && infoDict["sz접수시각"] != null) rawTime = infoDict["sz접수시각"].ToString();
        else if (infoDict.ContainsKey("sz예약시각") && infoDict["sz예약시각"] != null) rawTime = infoDict["sz예약시각"].ToString();

        if (!string.IsNullOrEmpty(rawTime) && rawTime.Length >= 12)
        {
            rawTime = rawTime.Substring(0, 12);
        }

        // [패치] 접수내용/예약내용 매핑 (기존 메서드 동일 로직)
        string? resNotes = null;
        if (infoDict.ContainsKey("접수내용") && infoDict["접수내용"] != null) resNotes = infoDict["접수내용"].ToString();
        else if (infoDict.ContainsKey("sz예약내용") && infoDict["sz예약내용"] != null) resNotes = infoDict["sz예약내용"].ToString();

        // basicInfo 유래 공통 필드 (모든 레코드에 동일 값)
        object? gender = infoDict.ContainsKey("b성별") ? infoDict["b성별"] : null;
        string? birthDate = infoDict.ContainsKey("sz생년월일") ? infoDict["sz생년월일"]?.ToString() : null;
        string? chartNumber = infoDict.ContainsKey("sz차트번호") ? infoDict["sz차트번호"]?.ToString() : null;
        string? patientName = infoDict.ContainsKey("sz이름") ? infoDict["sz이름"]?.ToString() : null;

        var patientRecords = new List<PatientFullDetail>();

        if (treatments.Count == 0)
        {
            // 진료기록 0건: 기존과 동일하게 treatment 필드 null + 전체 이미지로 단일 레코드 폴백
            patientRecords.Add(new PatientFullDetail(
                patientId, gender, birthDate, chartNumber,
                null, patientName, resNotes, null, null,
                doctorName, reservation_time: rawTime, images: images));
        }
        else
        {
            // 4-1. 진료일 기준 그룹핑 (PUB_V진료비내역은 시술 항목별 다행 -> 진료일로 묶는다)
            //      원래(내림차순) 순서를 유지하기 위해 최초 등장 순으로 진료일 목록을 쌓는다.
            var treatmentDates = new List<string>();
            var contentByDate = new Dictionary<string, List<string>>();
            var seenContentByDate = new Dictionary<string, HashSet<string>>();

            foreach (var row in treatments)
            {
                var rowDict = (IDictionary<string, object>)row;
                string? date = rowDict.ContainsKey("sz진료일") ? rowDict["sz진료일"]?.ToString() : null;
                if (string.IsNullOrWhiteSpace(date)) continue;

                if (!contentByDate.ContainsKey(date))
                {
                    contentByDate[date] = new List<string>();
                    seenContentByDate[date] = new HashSet<string>();
                    treatmentDates.Add(date);
                }

                // 그룹 내 치료내용: null/공백 제외 + 중복 제거 (원래 순서 유지)
                string? content = rowDict.ContainsKey("sz치료내용") ? rowDict["sz치료내용"]?.ToString() : null;
                if (!string.IsNullOrWhiteSpace(content) && seenContentByDate[date].Add(content))
                {
                    contentByDate[date].Add(content);
                }
            }

            // 방어적: 진료일이 전부 공백이라 그룹이 비면 단일 폴백으로 처리
            if (treatmentDates.Count == 0)
            {
                patientRecords.Add(new PatientFullDetail(
                    patientId, gender, birthDate, chartNumber,
                    null, patientName, resNotes, null, null,
                    doctorName, reservation_time: rawTime, images: images));
            }
            else
            {
                // 4-2. 이미지 배분: creation_time과 진료일을 숫자만 남긴 앞 8자리(yyyyMMdd)로 매칭.
                //      어느 진료일과도 매칭 안 되면(또는 creation_time이 null/8자리 미만) 가장 최신 진료건에 부착.
                string mostRecentDate = treatmentDates[0]; // 내림차순이므로 첫 항목이 최신
                var imagesByDate = new Dictionary<string, List<PatientImage>>();
                foreach (var d in treatmentDates) imagesByDate[d] = new List<PatientImage>();

                // 진료일별 8자리 키 사전 계산
                var dateKeys = new Dictionary<string, string?>();
                foreach (var d in treatmentDates) dateKeys[d] = ExtractDatePrefix(d);

                foreach (var img in images)
                {
                    string? imgKey = ExtractDatePrefix(img.creation_time);
                    string matched = mostRecentDate; // 기본값(폴백)
                    if (imgKey != null)
                    {
                        foreach (var d in treatmentDates)
                        {
                            if (dateKeys[d] == imgKey) { matched = d; break; }
                        }
                    }
                    imagesByDate[matched].Add(img);
                }

                // 5. 진료일마다 PatientFullDetail 1개씩 생성
                foreach (var date in treatmentDates)
                {
                    var contents = contentByDate[date];
                    string? treatmentContent = contents.Count > 0 ? string.Join(", ", contents) : null;

                    patientRecords.Add(new PatientFullDetail(
                        patientId, gender, birthDate, chartNumber,
                        date, patientName, resNotes, null, treatmentContent,
                        doctorName, reservation_time: rawTime, images: imagesByDate[date]));
                }
            }
        }

        // 6. 환자 1명당 1회 POST (진료일별 레코드 리스트 일괄 전송, 대용량 대비 타임아웃 연장)
        await SendToApiAsync(patientRecords, ct, FullHistoryPostTimeout);
    }

    // 담당의사 이름 조회 (ProcessSinglePatientAsync의 로직과 동일). 중복 최소화를 위한 헬퍼.
    private async Task<string?> GetDoctorNameAsync(SqlConnection conn, IDictionary<string, object> infoDict)
    {
        if (infoDict.ContainsKey("n담당의사") && infoDict["n담당의사"] != null)
        {
            return await conn.QueryFirstOrDefaultAsync<string>(
                "SELECT sz이름 FROM DentWeb.dbo.PUB_V직원정보 WHERE nID = @id", new { id = Convert.ToInt32(infoDict["n담당의사"]) });
        }
        return null;
    }

    // 문자열에서 숫자만 남긴 뒤 앞 8자리(yyyyMMdd)를 반환. 8자리 미만이거나 값이 없으면 null.
    private static string? ExtractDatePrefix(string? raw)
    {
        if (string.IsNullOrEmpty(raw)) return null;
        string digits = new string(raw.Where(char.IsDigit).ToArray());
        return digits.Length >= 8 ? digits.Substring(0, 8) : null;
    }

    private async Task<List<PatientImage>> FetchXrayImagesAsync(SqlConnection conn, int patientId)
    {
        var imageList = new List<PatientImage>();

        var xrayFiles = await conn.QueryAsync("DentWeb.dbo.PUB_P엑스레이", 
            new { PtID = patientId, DATE = "" }, commandType: CommandType.StoredProcedure);

        foreach (var file in xrayFiles)
        {
            string? filename = file.파일명;
            if (string.IsNullOrEmpty(filename)) continue;

            var imageData = await conn.QueryFirstOrDefaultAsync("DentWeb.dbo.PUB_GETImage", 
                new { Filename = filename }, commandType: CommandType.StoredProcedure);

            if (imageData?.file_stream is byte[] bytes)
            {
                imageList.Add(new PatientImage(
                    filename: filename,
                    type: file.Mod?.ToString(),
                    file_stream: Convert.ToBase64String(bytes),
                    creation_time: file.Time?.ToString()
                ));
            }
        }
        return imageList;
    }

    // Task 6 전체 이력 전송(이미지 base64 다건)은 기본 100초 타임아웃으로 부족할 수 있어 연장한다.
    private static readonly TimeSpan FullHistoryPostTimeout = TimeSpan.FromMinutes(10);

    private Task SendToApiAsync(PatientFullDetail data) => SendToApiAsync(new List<PatientFullDetail> { data });

    private async Task SendToApiAsync(List<PatientFullDetail> data, CancellationToken ct = default, TimeSpan? timeout = null)
    {
        var client = httpClientFactory.CreateClient();
        if (timeout.HasValue) client.Timeout = timeout.Value;
        var payload = new { patients = data };
        var response = await client.PostAsJsonAsync(GetInfoUrl(), payload, ct);

        if (!response.IsSuccessStatusCode)
        {
            string errorBody = await response.Content.ReadAsStringAsync(ct);
            throw new Exception($"Server Error ({response.StatusCode}): {errorBody}");
        }
    }
}