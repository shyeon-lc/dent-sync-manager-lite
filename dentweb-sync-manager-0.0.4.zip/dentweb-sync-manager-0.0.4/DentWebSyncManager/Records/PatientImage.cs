﻿namespace DentWebSyncManager.Records;

public record PatientImage(string filename, string? type, string? file_stream, string? creation_time);