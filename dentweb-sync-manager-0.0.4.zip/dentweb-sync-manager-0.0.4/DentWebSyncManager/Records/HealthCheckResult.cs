namespace DentWebSyncManager.Records;

public record HealthCheckResult(bool need_update, string target_version, List<string> target_names);