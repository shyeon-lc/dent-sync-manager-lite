namespace DentWebSyncManager.Records;

public record HealthCheckRequest(string store_id, string version, long health_epoch);