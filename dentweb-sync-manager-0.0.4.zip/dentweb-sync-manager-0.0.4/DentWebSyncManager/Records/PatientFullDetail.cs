﻿namespace DentWebSyncManager.Records;

public record PatientFullDetail(
    int patient_id,
    object? gender,
    string? birth_date,
    string? chart_number,
    string? treatment_date,
    string? patient_name,
    string? reservation_notes,
    string? checkin_notes,
    string? treatment_content,
    string? doctor_name,
    string? reservation_time,
    List<PatientImage> images
);
