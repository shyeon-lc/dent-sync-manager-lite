namespace DentWebSyncManager.Records;

public record HealthCheckResponse(int status, string message, HealthCheckResult result);