﻿namespace DentWebSyncManager.Records;

public record AppConfig(string DbIp, string StoreId);