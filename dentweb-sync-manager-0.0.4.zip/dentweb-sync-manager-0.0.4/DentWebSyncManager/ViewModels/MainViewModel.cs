using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DentWebSyncManager.Services;
using Application = System.Windows.Application;

namespace DentWebSyncManager.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly ITaskService _taskService;
    private readonly ILogService _logService;
    private readonly IAppStateService _appState;

    public string DbIp
    {
        get => _appState.DbIp;
        set
        {
            if (_appState.DbIp != value)
            {
                _appState.DbIp = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public string StoreId
    {
        get => _appState.StoreId;
        set
        {
            if (_appState.StoreId != value)
            {
                _appState.StoreId = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public bool IsTask1Running
    {
        get => _appState.IsTask1Running;
        set
        {
            if (_appState.IsTask1Running != value)
            {
                _appState.IsTask1Running = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public bool IsTask2Running
    {
        get => _appState.IsTask2Running;
        set
        {
            if (_appState.IsTask2Running != value)
            {
                _appState.IsTask2Running = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public bool IsTask5Running
    {
        get => _appState.IsTask5Running;
        set
        {
            if (_appState.IsTask5Running != value)
            {
                _appState.IsTask5Running = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public DateTime? Task5Date
    {
        get => _appState.Task5Date;
        set
        {
            if (_appState.Task5Date != value)
            {
                _appState.Task5Date = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public bool IsTask6Running
    {
        get => _appState.IsTask6Running;
        set
        {
            if (_appState.IsTask6Running != value)
            {
                _appState.IsTask6Running = value;
                OnPropertyChanged();
                _appState.SaveSettings();
            }
        }
    }

    public bool IsTask3Enabled
    {
        get => _appState.IsTask3Enabled;
        set
        {
            if (_appState.IsTask3Enabled != value)
            {
                _appState.IsTask3Enabled = value;
                OnPropertyChanged();
                _appState.SaveSettings();
                _logService.Log(value ? "🚀 Task3 당일 접수 전송 가동 (5분 주기)" : "🛑 3번 작업 중단됨");
            }
        }
    }

    public bool IsTask4Enabled
    {
        get => _appState.IsTask4Enabled;
        set
        {
            if (_appState.IsTask4Enabled != value)
            {
                _appState.IsTask4Enabled = value;
                OnPropertyChanged();
                _appState.SaveSettings();
                _logService.Log(value ? "⏰ Task4 전일 수납 전송 예약됨 (매일 10:00)" : "🛑 4번 예약 취소됨");
            }
        }
    }

    public ObservableCollection<string> Logs { get; } = new();

    private CancellationTokenSource? _cts1, _cts2, _cts5, _cts6;

    public MainViewModel(
        ITaskService taskService,
        ILogService logService, 
        IAppStateService appState)
    {
        _taskService = taskService;
        _logService = logService;
        _appState = appState;
        
        _logService.OnLogReceived += AppendLog;
    }

    public async Task InitializeAsync()
    {
        _logService.Log("🛠 시스템 초기화 중... 기존 작업 상태를 확인합니다.");

        // 1, 2, 5번 작업은 수동 시작형이므로 상태가 true이면 Toggle 호출
        if (IsTask1Running)
        {
            _logService.Log("♻ [재개] 1번 전체 이력 동기화 작업을 자동으로 다시 시작합니다.");
            // 현재 상태가 true이므로 ToggleTask1을 호출하면 logic 상 다시 실행됨
            // 단, ToggleTask1 내부에서 IsTask1Running을 다시 true로 보지 않도록 주의가 필요할 수 있음
            // 하지만 UI ToggleButton 바인딩 방식에서는 이미 true인 상태에서 로직을 타는 것이 맞음
            _ = ToggleTask1(); 
        }

        if (IsTask2Running)
        {
            _logService.Log("♻ [재개] 2번 명단 동기화 작업을 자동으로 다시 시작합니다.");
            _ = ToggleTask2();
        }

        if (IsTask5Running)
        {
            _logService.Log($"♻ [재개] 5번 특정일({Task5Date:yyyyMMdd}) 동기화 작업을 자동으로 다시 시작합니다.");
            _ = ToggleTask5();
        }

        if (IsTask6Running)
        {
            _logService.Log("♻ [재개] 6번 특정 명단 전체 진료기록 동기화 작업을 자동으로 다시 시작합니다.");
            _ = ToggleTask6();
        }

        if (IsTask3Enabled) _logService.Log("✅ 3번 당일 접수 주기 작업이 활성화되어 있습니다.");
        if (IsTask4Enabled) _logService.Log("✅ 4번 전일 수납 예약 작업이 활성화되어 있습니다.");
    }

    [RelayCommand]
    private async Task ToggleTask1()
    {
        if (IsTask1Running)
        {
            _cts1 = new CancellationTokenSource();
            _logService.Log("▶ Task1 전체 이력 동기화 시작");
            try
            {
                await Task.Run(() => _taskService.RunTask1Async(_cts1.Token));
            }
            finally
            {
                IsTask1Running = false;
            }
        }
        else
        {
            _cts1?.Cancel();
            _logService.Log("🛑 Task1 작업 중단됨");
        }
    }

    [RelayCommand]
    private async Task ToggleTask2()
    {
        if (IsTask2Running)
        {
            _cts2 = new CancellationTokenSource();
            _logService.Log("▶ Task2 명단 동기화 시작");
            try
            {
                await Task.Run(() => _taskService.RunTask2Async(_cts2.Token));
            }
            finally
            {
                IsTask2Running = false;
            }
        }
        else
        {
            _cts2?.Cancel();
            _logService.Log("🛑 Task2 작업 중단됨");
        }
    }

    [RelayCommand]
    private async Task ToggleTask5()
    {
        if (IsTask5Running)
        {
            if (Task5Date == null)
            {
                _logService.Log("❌ 날짜를 선택해주세요.");
                IsTask5Running = false;
                return;
            }

            string dateStr = Task5Date.Value.ToString("yyyyMMdd");
            _cts5 = new CancellationTokenSource();
            _logService.Log($"▶ Task5 특정일({dateStr}) 동기화 시작");
            try
            {
                await Task.Run(() => _taskService.RunTask5Async(dateStr, _cts5.Token));
            }
            finally
            {
                IsTask5Running = false;
            }
        }
        else
        {
            _cts5?.Cancel();
            _logService.Log("🛑 Task5 작업 중단됨");
        }
    }

    [RelayCommand]
    private async Task ToggleTask6()
    {
        if (IsTask6Running)
        {
            _cts6 = new CancellationTokenSource();
            _logService.Log("▶ Task6 특정 명단 전체 진료기록 동기화 시작");
            try
            {
                await Task.Run(() => _taskService.RunTask6Async(_cts6.Token));
            }
            finally
            {
                IsTask6Running = false;
            }
        }
        else
        {
            _cts6?.Cancel();
            _logService.Log("🛑 Task6 작업 중단됨");
        }
    }

    [RelayCommand]
    private async Task TestConnection()
    {
        _logService.Log("⏳ DB 연결을 테스트하는 중입니다... (최대 5초 대기)");
        bool success = await Task.Run(() => _taskService.TestDbConnectionAsync());
        if (success)
        {
            _logService.Log("✅ [성공] DB 서버와 정상적으로 연결되었습니다!");
        }
    }

    public void AppendLog(string message)
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            Logs.Add($"[{DateTime.Now:HH:mm:ss}] {message}");
            if (Logs.Count > 1000) Logs.RemoveAt(0);
        });
    }

    public void OnExit()
    {
        _cts1?.Cancel();
        _cts2?.Cancel();
        _cts5?.Cancel();
        _cts6?.Cancel();
    }
}
