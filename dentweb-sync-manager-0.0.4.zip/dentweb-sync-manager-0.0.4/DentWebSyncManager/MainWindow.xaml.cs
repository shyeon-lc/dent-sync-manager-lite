﻿using System.ComponentModel;
using System.Windows;
using Application = System.Windows.Application;

namespace DentWebSyncManager;

public partial class MainWindow
{
    private NotifyIcon? _notifyIcon;
    private bool _isActuallyClosing = false;

    public MainWindow()
    {
        InitializeComponent();
        SetupTrayIcon();
    }

    private void SetupTrayIcon()
    {
        _notifyIcon = new NotifyIcon
        {
            Icon = SystemIcons.Information,
            Visible = true,
            Text = "DentWeb Sync Manager"
        };
        _notifyIcon.DoubleClick += (s, e) => ShowWindow();

        var contextMenu = new ContextMenuStrip();
        contextMenu.Items.Add("화면 열기", null, (s, e) => ShowWindow());
        contextMenu.Items.Add("-");
        contextMenu.Items.Add("완전히 종료", null, (s, e) => ExitApplication());
        _notifyIcon.ContextMenuStrip = contextMenu;
    }

    private void ShowWindow() { this.Show(); this.WindowState = WindowState.Normal; this.Activate(); }

    private void ExitApplication()
    {
        _isActuallyClosing = true; 
        _notifyIcon?.Dispose();     
        Application.Current.Shutdown();
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        if (!_isActuallyClosing)
        {
            e.Cancel = true; 
            Hide();     
            _notifyIcon?.ShowBalloonTip(2000, "백그라운드 대기 중", "동기화 매니저가 트레이 아이콘으로 최소화되었습니다.", ToolTipIcon.Info);
        }
        else base.OnClosing(e);
    }
}