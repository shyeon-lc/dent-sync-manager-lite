; DentWeb Data Sync Manager (Pro) - Inno Setup Script
; 이 스크립트는 'dotnet publish' 결과물인 ./publish 폴더의 파일을 바탕으로 설치 파일을 생성합니다.

#define MyAppName "DentWeb Sync Manager"
#define MyAppVersion "0.0.4"
#define MyAppPublisher "Revieworks"
#define MyAppURL "https://revieworks.com"
#define MyAppExeName "DentWebSyncManager.exe"

[Setup]
AppId={{D3NTW3B-SYNC-MNGR-0001-A2B3-C4D5E6F7G8H9}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=Output
OutputBaseFilename=DentWebSyncManager_Setup_v{#MyAppVersion}
Compression=lzma
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "korean"; MessagesFile: "compiler:Languages\Korean.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startup"; Description: "윈도우 시작 시 자동 실행"; GroupDescription: "기타 설정:"

[Files]
; 메인 실행 파일 (경로 문자열 연결 방식 수정)
Source: "C:\works\wpf\dentweb-sync-manager\DentWebSyncManager\bin\Release\net10.0-windows\win-x64\publish\DentWebSyncManager.exe"; DestDir: "{app}"; Flags: ignoreversion
; 나머지 모든 라이브러리 파일
Source: "C:\works\wpf\dentweb-sync-manager\DentWebSyncManager\bin\Release\net10.0-windows\win-x64\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "DentWebSyncManager"; ValueData: """{app}\{#MyAppExeName}"""; Tasks: startup; Flags: uninsdeletevalue

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[Code]
// 설치 시작 전 프로그램이 실행 중인지 확인하고 종료 안내를 띄울 수 있습니다.
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
  // 간단한 체크 로직 (필요 시 추가 가능)
end;
