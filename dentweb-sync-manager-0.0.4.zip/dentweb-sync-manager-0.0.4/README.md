# DentWeb Data Sync Manager (Pro)

## 1. 프로그램 개요
DentWeb Data Sync Manager는 덴트웹(DentWeb) 데이터베이스(SQL Server)와 원격 중앙 API 서버 간의 환자 데이터 및 수납 내역을 안전하게 연동하기 위해 개발된 WPF 기반 윈도우 백그라운드 매니저입니다. 

**주요 특징**
- **안정적인 백그라운드 동작:** 창을 닫아도 트레이 아이콘으로 최소화되어 백그라운드(BackgroundService)에서 주기적인 동기화(Task 3, 4)와 Health Check 작업을 지속합니다.
- **자동 시작 지원:** 윈도우 레지스트리에 등록되어 PC 부팅 시 자동 실행됩니다.
- **실시간 모니터링:** UI 내 콘솔 창을 통해 실시간 동작 로그와 오류 상태를 파악할 수 있습니다.
- **Health Check 및 원격 제어:** 30초마다 서버와 통신하여 버전 업데이트 알림 수신 및 원격에서 지시한 특정 환자 명단(Task 2)을 즉시 자동 동기화합니다.

---

## 2. 초기 설정 및 연결 테스트
프로그램 초기 실행 시 설정값은 `config.json` (AppOptions) 파일에 저장됩니다.

1. **DB Server IP:** 덴트웹 DB가 설치된 서버의 로컬 IP 주소
2. **Store ID:** 본 원에 할당된 고유 식별 번호 (API 통신 시 필수)
3. **DB 연결 테스트:** 
   - 포트 1436을 사용하며, `dwpublic` 계정으로 SQL Server 연결을 테스트합니다. 방화벽 설정 확인이 필요합니다.

---

## 3. 동기화 기능 안내 (Sync Control Center)
UI의 토글 버튼을 통해 각 동기화를 관리합니다. (초록색 활성화 상태는 '실행 중' 또는 '예약/가동 중'을 의미합니다.)

- **[Task 1] 전체 이력 동기화 (ID기준)**
  - `last_patient_id.txt` 파일에 저장된 마지막 ID를 기준으로, 역순으로 전체 환자 데이터를 순차 전송합니다. 초기 데이터 구축 시 사용됩니다.

- **[Task 2] 특정 명단 동기화 (이름기준)**
  - 프로그램 폴더 내 `target_names.txt` 파일에 입력된 이름과 일치하는 환자 데이터를 찾아 전송합니다. Health Check를 통해 서버에서 명단을 받으면 자동으로 실행되고 파일은 비워집니다.

- **[Task 3] 당일 접수현황 (5분 주기)**
  - 당일 접수 환자 중 '수납 완료(상태:4)'인 건을 5분마다 묶어서(Bulk) 전송합니다.
  - 중복 전송 방지를 위해 전송된 ID는 `task3_state.json`에 저장되며, 매일 날짜가 변경되면 자동 초기화됩니다.

- **[Task 4] 전일 수납내역 (매일 10시 정각)**
  - 매일 오전 10시에 전일(어제) 수납 완료된 환자의 상세 데이터(엑스레이 이미지 포함)를 동기화합니다.
  - 월요일에는 토요일(2일 전) 데이터를 가져옵니다.

- **[Task 5] 특정일 수납내역 (수동)**
  - UI에서 DatePicker로 특정 날짜를 지정한 후 실행하면, 해당 일자의 수납 완료 환자 데이터를 수동으로 전송합니다. 누락 발생 시 유용합니다.

- **[Task 6] 특정 명단 전체 진료기록 (메디컨텐츠, 수동)**
  - 별도 파일 `target_names_medicontents.txt`에 입력된 이름과 일치하는 환자를 찾아, **환자당 전체 진료일 각각을 개별 레코드로** 전송합니다(Task 2의 "최신 1건" 한계 없이 전체 이력 수집).
  - 진료일별로 치료내용을 묶고 엑스레이 이미지를 진료일에 매칭해 배분하며, 환자 1명당 1회 POST로 일괄 전송합니다. 메디컨텐츠 데이터 구축용입니다.
  - Task 2와 달리 **Health Check로 자동 실행되지 않는 수동 기능**이며, 실행 후에도 명단 파일을 비우지 않습니다.

---

## 4. 수집 데이터 및 전송 항목
- **기본 정보:** 차트번호, 성별, 이름, 생년월일, 신환여부, 예약/접수 시간, 담당의사, 연락처, 메모
- **수납 상세:** 카드/현금 수납액, 결제 시각
- **진료 상세 (상세 동기화 시):** 최근 진료일, 치료 내용, 담당 의사 이름 매핑
  - ⚠️ 환자당 **최신 진료 1건만** 수집된다(과거 진료 이력 미수집). 상세는 **[7. 알려진 이슈](#7-알려진-이슈-진료기록-과거이력-미수집-환자당-top-1-한계)** 참고.
- **이미지 데이터:** Base64로 인코딩된 환자 엑스레이(`PUB_P엑스레이`) 파일 목록

---

## 5. 트레이 아이콘 및 프로그램 종료
- **최소화:** 창 닫기(X) 버튼 클릭 시 프로그램이 종료되지 않고 시스템 트레이로 숨김 처리됩니다. 백그라운드 스케줄러는 계속 동작합니다.
- **복원:** 트레이의 DentWeb Sync Manager 아이콘 더블 클릭
- **완전 종료:** 트레이 아이콘 우클릭 -> [완전히 종료] 선택 시에만 동기화 작업이 멈추고 안전하게 프로세스가 종료됩니다.

---

## 6. 주의사항 (Troubleshooting)
- 로그 창에 **`Server Error`** 혹은 DB 쿼리 오류 메시지가 지속될 경우 방화벽(1436)이나 네트워크 상태를 확인하세요.
- 프로그램이 설치된 폴더의 데이터 관리 파일들(`last_patient_id.txt`, `target_names.txt`, `target_names_medicontents.txt`, `task3_state.json`)을 임의로 수정하거나 삭제하지 마세요. 작업 이력이 유실될 수 있습니다.
- **Health Check 알림:** 새 버전 업데이트 필요 시 화면 로그로 공지됩니다. 안내에 따라 업데이트를 진행하세요.

---

## 7. 알려진 이슈: 진료기록 과거이력 미수집 (환자당 TOP 1 한계)

### 증상
한 환자에게 서로 다른 진료일자의 X-ray(EMR) 이미지가 여러 장 있어도, 서버에는 **가장 최근 진료 1건**의 진료기록(진료일 + 치료내용)만 저장된다. 그 결과 여러 날짜의 이미지가 단일 진료기록에 묶이고, 과거 진료 이력은 사실상 남지 않는다.

> 같은 환자가 시간에 걸쳐 여러 번 동기화되면(주로 매일 Task 4) 그때그때의 "최신 1건"이 진료일자별로 누적되므로, 진료기록이 여러 개 쌓인 환자도 있다. 이는 과거 이력을 한 번에 긁은 것이 아니라 **"동기화 시점마다의 최신"이 쌓인 결과**다. 재내원이 없던 환자는 진료기록이 1건만 남는다.

### 근본 원인 — 환자당 최신 1건만 조회
`DentWebSyncManager/Services/SyncService.cs:38`:

```sql
SELECT TOP 1 sz진료일, sz치료내용
FROM DentWeb.dbo.PUB_V진료비내역
WHERE n환자ID = @id
ORDER BY sz진료일 DESC
```

`QueryFirstOrDefaultAsync`로 실행되어 단일 `treatment`(→ `PatientFullDetail.treatment_date`, `treatment_content`)로만 매핑된다. 진료건을 순회하는 루프/리스트가 없다.

> 참고: **"전체 이력 동기화(Task 1)"** 는 `last_patient_id.txt` 기준으로 **모든 환자**를 훑는 기능이지, **환자 1명의 과거 진료건 다수**를 수집하는 기능이 아니다. 이름과 달리 환자당 진료기록은 항상 최신 1건이다.

### 언제 / 왜 — "제거"가 아니라 처음부터 없던 설계
- C# 최초 코드 커밋 **`6a2180f`(2026-04-29, author: wade)** 의 `SyncService.cs`에 위 `TOP 1` 쿼리가 이미 그대로 존재한다. 그 이전 `4f0fa02`("first commit")는 README뿐인 스캐폴딩이다. → **첫 코드 커밋(= GitHub 최초 업로드)부터 이 상태**였고, 진료내용을 다건 수집하던 버전은 모든 branch/tag/stash/dangling object 어디에도 없다.
- 전신(前身) **PowerShell 스크립트**(`REVIEWWORKS/script/SendDentWebAdditionalData_init.ps1:106`)도 동일하게 `SELECT TOP 1 sz진료일, sz치료내용 FROM DentWeb.dbo.TB_진료비내역 ... ORDER BY sz진료일 DESC`로 최신 1건만 가져왔다(주석: `- 첫 번째 진료 정보만 사용`). → PowerShell→C# 전환은 접근 대상을 base table `TB_진료비내역`에서 view `PUB_V진료비내역`로 바꾼 리팩터링일 뿐, **진료내용 최신-1건 제약은 두 세대 모두 처음부터 동일**했다. (C# `SyncService.cs:44` 의 `(PS 스크립트 동일 로직)` 주석과 동일 API 엔드포인트가 계보를 확증.)

**결론: 이 이슈는 어느 시점에 "유실"된 것이 아니라 처음부터(전신 PowerShell 시절부터) 미구현이었다.**

> **부분 완화(2026-07):** 신규 **[Task 6] 특정 명단 전체 진료기록 (메디컨텐츠)** 로 **특정 명단에 한해 전체 진료 이력 수집이 가능**해졌다(`target_names_medicontents.txt`, 환자당 진료일별 다건 전송). 다만 이는 수동 명단 대상의 별도 경로이며, 상시 경로인 Task 1/2/4/5는 여전히 환자당 최신 1건 한계에 해당한다.

### 데이터 흐름 (End-to-End)
```
DentWeb (MSSQL, PUB_V진료비내역)
  → dentweb-sync-manager (C#, SyncService.cs: 환자당 TOP 1)
  → POST crawling-service  /unrestricted/review-booster/medicontents/patient-info/{hospital-id}
  → ReviewBoosterService.receiveAdditionalPatientInfo
       · boost_dental_patient_info UPSERT (key = hospitalId + patientId + treatmentDate + chartNumber)
       · payload의 모든 이미지를 그 1개 진료기록 행에 attach
  → Kafka → medicontents BE (Postgres, emr_treatment_records / emr_images = 읽기 전용)
```

수신 서버(crawling-service)와 medicontents BE 어디에도 DentWeb/MSSQL 직접 연결이나 배치·백필 코드가 없다(datasource 전부 PostgreSQL). → 서버가 자체적으로 과거 이력을 보충할 수 없고, **오직 온프레미스 앱이 push한 만큼만** 저장된다.

### 수정 방향
- `SyncService.cs` 진료내역 조회에서 **`TOP 1` 제거** → `ORDER BY sz진료일 DESC` 정렬된 **전체(또는 N건)** 진료 목록 조회(`QueryAsync` + `List` 매핑).
- 이미지를 각 진료건의 `sz진료일`에 매칭하여 진료기록 배열로 전송.
- **서버 API 변경 불필요**: `receiveAdditionalPatientInfo`가 이미 `(hospitalId, patientId, treatmentDate, chartNumber)` 키로 진료일자별 UPSERT를 하므로, 클라이언트가 진료건 리스트를 보내면 서버가 진료일자별로 다건 저장한다.

### 주의
동일 뷰 `PUB_V진료비내역`을 쓰는 **수납/영수증 동기화**(`TaskService`, `allPayments`)는 `TOP 1` 없이 환자당 여러 행을 수집하지만, 수집 컬럼이 수납시각·카드수납액 등 **결제 필드**일 뿐 진료내용(`sz치료내용`)이 아니므로 본 이슈와는 별개 기능이다.
